# LOD system
It's for LOD change detection and sending information to those objects that needs to change.
You might have better mesh management with multimesh, in that case please let me know or make a pull request.
For downloading just this project you can use [DownGit](https://minhaskamal.github.io/DownGit/)     

## Walkthrough
<div align="left">
      <a href="https://youtu.be/ZWDEMJYm5W8">
     <img 
      src="https://img.youtube.com/vi/ZWDEMJYm5W8/0.jpg" 
      alt="State machine walkthrough" 
      style="width:100%;">
      </a>
    </div>
