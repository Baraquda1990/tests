# 3D FPS controller
It's a simple-ish controller to show some mechanics (walk, run, jump, crouch) and use state machine to control them and allow implement new ones.    
Also it has solution for slopes and moving platforms.    
By default project uses GLES2 but it includes HDR and procedural sky environments for GLES3.    

