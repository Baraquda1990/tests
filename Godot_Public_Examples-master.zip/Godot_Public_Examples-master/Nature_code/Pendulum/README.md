# Pendulum
Basic physics calculations for pendulum.
For downloading just this project you can use [DownGit](https://minhaskamal.github.io/DownGit/)     

## Tutorial
<div align="left">
      <a href="https://youtu.be/J1ClXGZIh00">
     <img 
      src="https://img.youtube.com/vi/J1ClXGZIh00/0.jpg" 
      alt="Pendulum physics" 
      style="width:100%;">
      </a>
    </div>
