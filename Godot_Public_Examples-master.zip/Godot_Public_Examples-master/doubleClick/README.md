# Double click

## Video & tutorial for px/frame tranlation for delta time
<div align="center">
      <a href="https://youtu.be/T_5vizt7T8o">
     <img 
      src="https://img.youtube.com/vi/T_5vizt7T8o/0.jpg" 
      alt="tutorial Multi-functional double click, button animation, TouchScreenButton" 
      style="width:100%;">
      </a>
    </div>