# Weapon change
It's for LOD change detection and sending information to those objects that needs to change.
You might have better mesh management with multimesh, in that case please let me know or make a pull request.
For downloading just this project you can use [DownGit](https://minhaskamal.github.io/DownGit/)     

## Tutorial
<div align="left">
      <a href="https://youtu.be/kjqjl4Dwnnc">
     <img 
      src="https://img.youtube.com/vi/kjqjl4Dwnnc/0.jpg" 
      alt="State machine walkthrough" 
      style="width:100%;">
      </a>
    </div>
