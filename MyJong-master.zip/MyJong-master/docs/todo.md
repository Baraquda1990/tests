# Todo

- **LayoutEditor** 
  - MetaData: Name, Description, Picture?
- **Main Menu**
  - Logo
  - Preset Layouts, Custom Layouts, Workshop layouts distinct
  - Quick Play 
- **Quick Play**
  - Random layout from preset layouts and favorites
    - Set in preferences: Include Defaults? Include Favorites? Game Mode?
- Music, Soundeffects
- GUI Buttons / Improvements