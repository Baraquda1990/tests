'use strict';

var FxaModuleForgotPasswordSuccess = (function() {

  var Module = Object.create(FxaModule);
  Module.init = function init() {
  };

  return Module;
}());

