<details>
    <summary>NOTE</summary>
        Work in progress
</details>

# Table of Contents
1. [KaiOS Hello World](#kaios-hello-world)
2. [Getting Started](#getting-started)
    1. [Prerequisites](#prerequisites)
    2. [Installation](#installation)
3. [Usage](#usage)
4. [Built With](#built-with)
5. [Acknowledgements](#Acknowledgments)

## KaiOS Hello World

Just a Hello World App for [KaiOS](https://developer.kaiostech.com/) 

## Getting Started

I do not know what to write here exactly, so I will just write this.  
Oh, wait. This might be helpful. [KaisOS Getting Started official documentation](https://developer.kaiostech.com/getting-started)  

### Prerequisites

Download the Simulator [here](https://developer.kaiostech.com/getting-started/env-setup/simulator). 

```
No codes. Just clicks. 
```

### Installation  

• clone this repo in your machine
```bash 
git clone https://github.com/sawthinkar/KaiOS-helloworld.git
```

## Usage  

• open Kaiosrt (simulator) and import the project using `Open Packaged App...` on the far left column. 

![KaiOS Simulator](/screenshots/kaios_simulator.png)

``` 
then just click run
``` 

![Hello World in Kaiosrt](/screenshots/helloworld_simulator.png)

*You can also try this in WebIDE like [CodeSandbox](https://codesandbox.io/s/my-first-vanilla-app-kaios-kv3zi)* 

![Hello World in WebIDE](/screenshots/helloworld_websimulator.png) 

*[TODO LIST Vanilla App](https://codesandbox.io/s/my-first-vanilla-app-kaios-ef0ge) in WebIDE* 

![Hello World in WebIDE](/screenshots/kaios_vanilla_app.png) 

<!-- ## Deployment

Add additional notes about how to deploy this on a live system -->

## Built With 

HTML, Javascript 

<!-- ## Contributing -->

<!-- ## Versioning -->

<!-- ## Authors -->

<!-- ## License

[MIT](https://choosealicense.com/licenses/mit/) 

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details -->

## Acknowledgments
(References/Credits)  
[ReadMe Sample Templates](https://github.com/sawthinkar/README.md)


**NOTE: This is my very first attempt of making a proper README.md**

---
