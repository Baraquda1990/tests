# License of assets

### Bullet (bullet) by oglsdl (https://opengameart.org/content/bullet-symbol)

License (CC0)
http://creativecommons.org/publicdomain/zero/1.0/

You may use these graphics in personal and commercial projects.
Credit (oglsdl or https://opengameart.org/users/oglsdl) would be nice but is not mandatory.

### Zombie & Player (zombie & player) by Ian Peter (https://opengameart.org/content/top-down-shooter-and-zombie)

License (CC0)
http://creativecommons.org/publicdomain/zero/1.0/

You may use these graphics in personal and commercial projects.
Credit (Ian Peter or https://opengameart.org/users/ian-peter) would be nice but is not mandatory.

### Ground Tile (ground_tile) by Nekith (https://opengameart.org/content/top-down-shooter-and-zombie)

License (CC0)
http://creativecommons.org/publicdomain/zero/1.0/

You may use these graphics in personal and commercial projects.
Credit (Nekith or https://opengameart.org/users/nekith) would be nice but is not mandatory.

### Explosion (explosion) by GameProgrammingSlave (https://opengameart.org/content/top-down-shooter-and-zombie)

License (CC0)
http://creativecommons.org/publicdomain/zero/1.0/

You may use these graphics in personal and commercial projects.
Credit (GameProgrammingSlave or https://opengameart.org/users/gameprogrammingslave) would be nice but is not mandatory.