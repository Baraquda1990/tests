# Особые апдейты my_chat_member и chat_member 

В этом каталоге исходники к главе https://mastergroosha.github.io/aiogram-3-guide/special-updates/
