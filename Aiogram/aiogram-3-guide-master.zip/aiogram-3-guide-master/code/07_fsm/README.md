# Конечные автоматы (FSM)

В этом каталоге исходники к главе https://mastergroosha.github.io/aiogram-3-guide/fsm/
