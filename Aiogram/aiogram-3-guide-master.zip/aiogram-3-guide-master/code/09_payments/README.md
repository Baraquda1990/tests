# Платежи

В этом каталоге исходники к главе https://mastergroosha.github.io/aiogram-3-guide/payments/

Для запуска бота (требуется Python 3.11 и выше) скопируйте файл `settings.example.toml` под именем 
`settings.toml` и заполните своими значениями. Далее можно запустить (из-под venv) командой:

```python
CONFIG_FILE_PATH=/path/to/settings.toml python -m bot
```

Также в репозитории лежит файл [donatebot.example.service](donatebot.example.service) 
для запуска через Systemd.
