# Пишем Telegram-ботов c aiogram 3.x 

Перед вами книга по разработке Telegram-ботов на языке Python с использованием фреймворка **[aiogram 3.x](https://github.com/aiogram/aiogram/tree/dev-3.x)**.

Ознакомиться с книгой можно здесь: https://mastergroosha.github.io/aiogram-3-guide/  
Исходные тексты ко всем главам расположены [в папке code](https://github.com/MasterGroosha/aiogram-3-guide/tree/master/code).

Предыдущие версии:
* aiogram 2.x (2019-2021): https://mastergroosha.github.io/aiogram-2-guide/
* pyTelegramBotAPI (2015-2019): https://mastergroosha.github.io/telegram-tutorial/

Книга собрана с помощью [mkdocs-material](https://squidfunk.github.io/mkdocs-material/).
